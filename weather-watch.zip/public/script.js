
async function getWeather() {
  const city = document.getElementById("cityInput").value;
  const url = `http://localhost:3000/weather?city=${city}`; // Change this when deployed

  try {
    const response = await fetch(url);
    const data = await response.json();

    if (data.error) {
      document.getElementById("weatherResult").innerHTML = `<p>${data.error}</p>`;
      document.body.style.backgroundColor = "#eee";
      return;
    }

    const weather = data.weather;
    const temp = data.temp;
    const humidity = data.humidity;
    const tempMin = data.temp_min;
    const tempMax = data.temp_max;

    const localTime = new Date((data.dt + data.timezone) * 1000);
    const localHour = localTime.getUTCHours();

    applyTheme(weather, localHour);

    const resultHTML = `
      <h2>${data.city}</h2>
      <p>${data.description}</p>
      <p>🌡 ${temp} °C</p>
      <p>Min: ${tempMin} °C | Max: ${tempMax} °C</p>
      <p>💧 Humidity: ${humidity}%</p>
    `;
    document.getElementById("weatherResult").innerHTML = resultHTML;
  } catch (err) {
    document.getElementById("weatherResult").innerHTML = `<p>Error fetching data</p>`;
    document.body.style.backgroundColor = "#eee";
  }
}

function applyTheme(weather, localHour) {
  let bgColor = "#eee";

  if (localHour >= 20 || localHour <= 5) {
    bgColor = "#001f3f"; // midnight blue
  } else if (weather === "Clear") {
    bgColor = "#FFD700"; // yellow
  } else if (weather === "Rain" || weather === "Drizzle" || weather === "Thunderstorm") {
    bgColor = "#007BFF"; // blue
  } else if (weather === "Clouds") {
    bgColor = "#B0C4DE"; // light steel blue
  } else {
    bgColor = "#D3D3D3"; // default light gray
  }

  document.body.style.backgroundColor = bgColor;
}
